#ifndef COORDINATE_H
#define COORDINATE_H

struct Coordinate
{
	double x;
	double y;
	
	double t;
};
#endif // !COORDINATE_H
